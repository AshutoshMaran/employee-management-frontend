// export const apiurl=" http://192.168.1.1:5000/"

// export const apiurl="https://nixiescmsapi.mydemoapps.online/"
export const apiurl="http://localhost:5000/"

// export const apiurl="https://sfz9s4m9-5000.inc1.devtunnels.ms/" 
// export const apiurl="https://sfz9s4m9-5000.inc1.devtunnels.ms/"

// export const apiurl ="http://192.168.1.24:5000/upload/"
// export const apiurl ="http://10.243.174.217:3001/auth/"

