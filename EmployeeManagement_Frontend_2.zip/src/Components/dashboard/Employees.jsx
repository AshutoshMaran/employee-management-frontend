import React from 'react'
   
import EmployeeOverview from './Emplist'
import Employeeslist from './Employeeslist'
const Employees = () => {
  return (
    <div>
        {/* <EmployeeOverview/> */}
        <Employeeslist/>
  
  
    </div>
  )
}

export default Employees
