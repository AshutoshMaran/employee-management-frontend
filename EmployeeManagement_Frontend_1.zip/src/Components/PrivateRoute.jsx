import React from 'react';

const PrivateRoute = ({ children }) => {

  return children;
};

export default PrivateRoute;
