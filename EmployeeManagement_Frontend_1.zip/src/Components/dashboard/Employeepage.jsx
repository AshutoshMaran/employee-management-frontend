import React from 'react'

const Employeepage = () => {
  return (
    <div>Employeepage</div>
  )
}

export default Employeepage